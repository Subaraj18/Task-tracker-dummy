
import React from 'react';

const TaskForm = () => {
    return (
        <div>
            <h2>Task Form (Dummy)</h2>
            <form>
                <input type="text" placeholder="Enter task name" />
                <button type="submit">Add Task</button>
            </form>
        </div>
    );
};

export default TaskForm;
