
import React from 'react';

const TaskList = () => {
    return (
        <div>
            <h2>Task List (Dummy)</h2>
            <ul>
                <li>Learn React</li>
                <li>Practice .NET Core</li>
            </ul>
        </div>
    );
};

export default TaskList;
