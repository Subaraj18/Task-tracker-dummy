
# Task Tracker Dummy Project

A dummy full-stack setup with React frontend and ASP.NET Core backend.

## Frontend
- React components: TaskForm, TaskList

## Backend
- ASP.NET Core Web API with TaskController

Use this to showcase your GitHub portfolio while you're preparing real apps.
