
using Microsoft.AspNetCore.Mvc;
using TaskTracker.Models;
using System.Collections.Generic;

namespace TaskTracker.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<Task>> Get()
        {
            return new List<Task>
            {
                new Task { Id = 1, Title = "Learn React", IsCompleted = false },
                new Task { Id = 2, Title = "Learn .NET Core", IsCompleted = true }
            };
        }
    }
}
